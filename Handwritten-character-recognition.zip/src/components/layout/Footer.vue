<script lang="ts" setup>

</script>

<template>
  <div />
</template>

<style scoped>
.footer {
  padding: 1rem;
  background: #f8f9fa;
  text-align: center;
}
</style>
