/// <reference types="vite/client" />

// 全局变量类型声明
declare const __APP_ENV__: string
declare const __API_URL__: string
declare const __APP_TITLE__: string
declare const __BACKEND_URL__: string